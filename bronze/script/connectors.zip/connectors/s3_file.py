"""
S3 File Source Connector — AWS Glue Data Pipeline.

Extracts flat files (CSV, JSON, NDJSON, Parquet, Text) from an external
or internal S3 bucket and streams records to the Bronze layer.

Required bronze_config.json keys (source_systems.<name>):
  source_bucket      : S3 bucket to read files from
  file_prefix        : S3 key prefix for all files of this source (e.g. 'raw/hr/')
  file_format        : 'csv' | 'tsv' | 'json' | 'ndjson' | 'parquet' | 'text'
  fetch_mode         : 'all' — all files modified after watermark (default)
                       'latest' — only the single most recently modified file
  table_paths        : Optional per-table path overrides { table_name: "path/prefix/" }
  table_fetch_modes  : Optional per-table fetch_mode overrides { table_name: "latest" }
  delimiter          : Column delimiter for CSV/TSV (default: ',')
  has_header         : Whether CSV has a header row (default: true)
  encoding           : File encoding (default: 'utf-8')
  multi_line         : Enable multi-line / multi-paragraph CSV records (default: true)
  escape             : Escape character for quotes/text fields (default: '\\')

Cross-account S3 access: if Secrets Manager contains 'aws_access_key_id' and
'aws_secret_access_key', a cross-account S3 client is used; otherwise the
Glue execution role (IAM) is used.
"""

import csv
import io
import json
import logging
import sys
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple

import boto3

logger = logging.getLogger(__name__)

_SUPPORTED_FORMATS = ('csv', 'tsv', 'json', 'ndjson', 'parquet', 'text')
_VALID_FETCH_MODES = ('all', 'latest')


class S3FileConnector:
    """
    Ingestion connector for reading files from S3 source buckets.
    Supports two fetch modes: 'all' (all new files) or 'latest' (most recent file only).
    """

    @classmethod
    def fetch_delta(
        cls,
        last_load_date: str,
        secret_dict: Dict[str, Any],
        table_name: str,
        source_config: Dict[str, Any],
        custom_query: Optional[str] = None,
        on_chunk_callback: Optional[Callable[[List[Dict[str, Any]], int], None]] = None,
        s3_chunk_size: int = 10000,
    ) -> None:
        """
        Scans the source S3 path for files and streams records to Bronze.

        fetch_mode = 'all'   : Reads all files modified after last_load_date.
        fetch_mode = 'latest': Reads only the most recently modified file in the path,
                               regardless of the watermark. Useful for full-refresh feeds
                               (e.g. daily employee export).
        """
        config = source_config or {}

        source_bucket = config.get('source_bucket')
        if not source_bucket:
            raise ValueError(
                f"S3FileConnector for '{table_name}': 'source_bucket' is not configured. "
                "Add 'source_bucket' to bronze_config.json "
                f"(source_systems.<name>.source_bucket)."
            )

        # Dynamic {env} interpolation fallback if not already performed by ConfigLoader
        env_val = str(config.get('env') or '').strip().lower()
        if not env_val:
            import os
            env_val = str(os.environ.get('ENV') or os.environ.get('ENVIRONMENT') or 'dev').strip().lower()
        if '{env}' in source_bucket or '{ENV}' in source_bucket:
            source_bucket = source_bucket.replace('{env}', env_val).replace('{ENV}', env_val.upper())

        # Per-table path override: tables.<table_name>.file_path > table_paths > global file_prefix
        tables_dict = config.get('tables', {})
        table_cfg = tables_dict.get(table_name)
        if not table_cfg and isinstance(tables_dict, dict):
            # Check alternative keys: hyphens, underscores, or stripping source_system prefix (e.g. 'users' vs 'genesys_users')
            alt_keys = [
                table_name.replace('_', '-'),
                table_name.replace('-', '_'),
                table_name.split('_', 1)[-1] if '_' in table_name else '',
            ]
            for alt in alt_keys:
                if alt and alt in tables_dict and isinstance(tables_dict[alt], dict):
                    table_cfg = tables_dict[alt]
                    break
        if not table_cfg or not isinstance(table_cfg, dict):
            table_cfg = {}

        table_paths = config.get('table_paths', {})
        raw_path = table_cfg.get('file_path') or table_paths.get(table_name) or config.get('file_prefix', f'raw/{table_name}/')

        # If file_path contains wildcards (e.g. "raw_feed/genesys/conversations_*.csv"), split into prefix and pattern
        file_pattern = table_cfg.get('file_pattern') or config.get('file_pattern')
        raw_path_str = str(raw_path).strip().rstrip('/')
        if any(char in raw_path_str for char in ('*', '?', '[')):
            if '/' in raw_path_str:
                prefix_part, pattern_part = raw_path_str.rsplit('/', 1)
                file_prefix = prefix_part + '/'
                if any(char in pattern_part for char in ('*', '?', '[')):
                    file_pattern = pattern_part
                else:
                    file_prefix = raw_path_str + '/'
            else:
                file_prefix = ''
                file_pattern = raw_path_str
        else:
            file_prefix = raw_path if raw_path.endswith('/') else raw_path + '/'

        # Per-table fetch_mode override: tables.<table_name>.fetch_mode > table_fetch_modes > global fetch_mode
        table_modes = config.get('table_fetch_modes', {})
        raw_mode = table_cfg.get('fetch_mode') or table_modes.get(table_name) or config.get('fetch_mode', 'all')
        
        # Check CLI args for dynamic override
        import sys
        for arg in sys.argv[1:]:
            if arg.startswith('--FETCH_MODE=') or arg.startswith('--fetch_mode='):
                raw_mode = arg.split('=', 1)[1]
            elif arg in ('--FETCH_MODE', '--fetch_mode'):
                idx = sys.argv.index(arg)
                if idx + 1 < len(sys.argv) and not sys.argv[idx + 1].startswith('--'):
                    raw_mode = sys.argv[idx + 1]

        fetch_mode = str(raw_mode).strip().lower()
        if fetch_mode not in _VALID_FETCH_MODES:
            raise ValueError(
                f"S3FileConnector for '{table_name}': invalid 'fetch_mode' = '{fetch_mode}'. "
                f"Allowed: {_VALID_FETCH_MODES}. "
                "Set 'fetch_mode' in bronze_config.json (source_systems.<name>.fetch_mode) or via --FETCH_MODE."
            )

        file_format = (config.get('file_format') or 'csv').lower()
        if file_format not in _SUPPORTED_FORMATS:
            raise ValueError(
                f"S3FileConnector for '{table_name}': unsupported 'file_format' = '{file_format}'. "
                f"Allowed: {_SUPPORTED_FORMATS}."
            )
        delimiter  = table_cfg.get('delimiter') or config.get('delimiter', ',')
        has_header_raw = table_cfg.get('has_header', config.get('has_header', True))
        has_header = str(has_header_raw).strip().lower() in ('true', '1', 'yes') if isinstance(has_header_raw, str) else bool(has_header_raw)
        encoding   = table_cfg.get('encoding') or config.get('encoding', 'utf-8')

        # multiLine / multi_line option (handles multi-paragraph text fields)
        raw_multiline = (
            table_cfg.get('multiLine')
            if 'multiLine' in table_cfg
            else table_cfg.get('multi_line')
            if 'multi_line' in table_cfg
            else table_cfg.get('multiline')
            if 'multiline' in table_cfg
            else config.get('multiLine')
            if 'multiLine' in config
            else config.get('multi_line')
            if 'multi_line' in config
            else config.get('multiline', True)
        )
        if isinstance(raw_multiline, str):
            multi_line = raw_multiline.strip().lower() in ('true', '1', 'yes')
        else:
            multi_line = bool(raw_multiline)

        # escape / escapechar option (handles escaped characters/quotes e.g. \" inside CSV fields)
        raw_escape = (
            table_cfg.get('escape')
            if 'escape' in table_cfg
            else table_cfg.get('escapechar')
            if 'escapechar' in table_cfg
            else config.get('escape')
            if 'escape' in config
            else config.get('escapechar', '\\')
        )
        escape = str(raw_escape) if raw_escape is not None else None
        if escape and escape.lower() in ('none', 'null', 'false', ''):
            escape = None

        # Build S3 client (cross-account if explicit credentials provided)
        if secret_dict.get('aws_access_key_id') and secret_dict.get('aws_secret_access_key'):
            s3 = boto3.client(
                's3',
                aws_access_key_id=secret_dict['aws_access_key_id'],
                aws_secret_access_key=secret_dict['aws_secret_access_key'],
                aws_session_token=secret_dict.get('aws_session_token'),
            )
        else:
            s3 = boto3.client('s3')

        # Parse watermark and optional upper_bound (support 'YYYY-MM-DD HH:MM:SS' and ISO-8601)
        try:
            hwm_str = str(last_load_date).strip()
            if hwm_str.endswith('Z') or hwm_str.endswith('z'):
                hwm_str = hwm_str[:-1] + '+00:00'
            elif ' ' in hwm_str and '+' not in hwm_str and '-' not in hwm_str[10:]:
                hwm_str = hwm_str.replace(' ', 'T') + '+00:00'
            elif 'T' in hwm_str and '+' not in hwm_str and '-' not in hwm_str[10:]:
                hwm_str = hwm_str + '+00:00'
            hwm = datetime.fromisoformat(hwm_str)
            if hwm.tzinfo is None:
                hwm = hwm.replace(tzinfo=timezone.utc)
        except Exception:
            hwm = datetime.min.replace(tzinfo=timezone.utc)

        upper_bound_str = config.get('upper_bound')
        ub_dt = None
        if upper_bound_str and str(upper_bound_str).strip():
            try:
                ub_clean = str(upper_bound_str).strip()
                if ub_clean.endswith('Z') or ub_clean.endswith('z'):
                    ub_clean = ub_clean[:-1] + '+00:00'
                elif ' ' in ub_clean and '+' not in ub_clean and '-' not in ub_clean[10:]:
                    ub_clean = ub_clean.replace(' ', 'T') + '+00:00'
                elif 'T' in ub_clean and '+' not in ub_clean and '-' not in ub_clean[10:]:
                    ub_clean = ub_clean + '+00:00'
                ub_dt = datetime.fromisoformat(ub_clean)
                if ub_dt.tzinfo is None:
                    ub_dt = ub_dt.replace(tzinfo=timezone.utc)
            except Exception:
                logger.warning(f"[S3File/{table_name}] Could not parse upper_bound '{upper_bound_str}', ignoring.")

        # List all matching files
        candidates: List[Tuple[str, datetime]] = []
        paginator = s3.get_paginator('list_objects_v2')
        for page in paginator.paginate(Bucket=source_bucket, Prefix=file_prefix):
            for obj in page.get('Contents', []):
                key = obj['Key']
                if key.endswith('/'):
                    continue
                # If file pattern configured or matching table_name in filename
                filename = key.split('/')[-1]
                if file_pattern:
                    import fnmatch
                    if not fnmatch.fnmatch(filename, file_pattern):
                        continue
                elif not file_prefix.rstrip('/').endswith(table_name):
                    # If prefix is a shared parent directory, ensure filename starts with table_name or short name
                    short_table_name = table_name.split('_', 1)[-1] if '_' in table_name else table_name
                    matches_name = (
                        filename.startswith(f"{table_name}_") or filename.startswith(f"{table_name}.") or
                        filename.startswith(f"{short_table_name}_") or filename.startswith(f"{short_table_name}.")
                    )
                    if not matches_name:
                        continue

                mtime = obj['LastModified']
                within_ub = (ub_dt is None) or (mtime <= ub_dt)
                if (fetch_mode == 'latest' or mtime > hwm) and within_ub:
                    candidates.append((key, mtime))

        if not candidates:
            logger.info(
                f"[S3File/{table_name}] No files found in "
                f"s3://{source_bucket}/{file_prefix} (fetch_mode={fetch_mode}, pattern={file_pattern}, watermark={last_load_date})."
            )
            return

        # Apply fetch_mode
        if fetch_mode == 'latest':
            selected = [max(candidates, key=lambda x: x[1])]
            logger.info(f"[S3File/{table_name}] fetch_mode=latest → reading: {selected[0][0]}")
        else:
            selected = sorted(candidates, key=lambda x: x[1])
            logger.info(
                f"[S3File/{table_name}] fetch_mode=all → {len(selected)} file(s) "
                f"in s3://{source_bucket}/{file_prefix} modified after {last_load_date}."
            )

        buffer: List[Dict[str, Any]] = []
        part = 1

        for key, mtime in selected:
            logger.info(f"[S3File/{table_name}] Reading: s3://{source_bucket}/{key} (modified: {mtime})")
            try:
                body_bytes = s3.get_object(Bucket=source_bucket, Key=key)['Body'].read()
                records    = cls._parse(
                    body_bytes,
                    file_format,
                    delimiter,
                    has_header,
                    encoding,
                    key,
                    multi_line=multi_line,
                    escape=escape,
                )
            except Exception as err:
                logger.error(f"[S3File/{table_name}] Failed to read/parse '{key}': {err}")
                raise

            buffer.extend(records)
            while len(buffer) >= s3_chunk_size:
                if on_chunk_callback:
                    on_chunk_callback(buffer[:s3_chunk_size], part)
                buffer = buffer[s3_chunk_size:]
                part  += 1

        if buffer and on_chunk_callback:
            on_chunk_callback(buffer, part)

    @classmethod
    def _parse(
        cls,
        body_bytes: bytes,
        file_format: str,
        delimiter: str,
        has_header: bool,
        encoding: str,
        source_key: str,
        multi_line: bool = True,
        escape: Optional[str] = '\\',
    ) -> List[Dict[str, Any]]:
        """Parses raw file bytes into a list of record dicts."""
        text = body_bytes.decode(encoding, errors='replace')

        if file_format in ('csv', 'tsv'):
            sep  = '\t' if file_format == 'tsv' else delimiter
            escapechar = escape[0] if (escape and isinstance(escape, str)) else None

            # Increase CSV field size limit for large multi-paragraph text fields
            try:
                csv.field_size_limit(sys.maxsize)
            except (OverflowError, AttributeError):
                csv.field_size_limit(2147483647)

            reader_kwargs: Dict[str, Any] = {'delimiter': sep}
            if escapechar:
                reader_kwargs['escapechar'] = escapechar

            if multi_line:
                # Use io.StringIO to preserve embedded newlines inside quoted fields
                # (handles multi-paragraph text fields properly)
                if not text.strip():
                    return []
                f = io.StringIO(text)
                if has_header:
                    return [dict(row) for row in csv.DictReader(f, **reader_kwargs)]
                return [
                    {f'col_{i}': v for i, v in enumerate(row)}
                    for row in csv.reader(f, **reader_kwargs)
                ]

            lines = text.splitlines()
            if not lines:
                return []
            if has_header:
                return [dict(row) for row in csv.DictReader(lines, **reader_kwargs)]
            return [
                {f'col_{i}': v for i, v in enumerate(row)}
                for row in csv.reader(lines, **reader_kwargs)
            ]

        if file_format in ('json', 'ndjson'):
            records: List[Dict[str, Any]] = []
            for line in text.splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    if isinstance(obj, dict):
                        records.append(obj)
                except json.JSONDecodeError:
                    break
            if records:
                return records
            # Fallback: full JSON array
            parsed = json.loads(text)
            if isinstance(parsed, list):
                return parsed
            if isinstance(parsed, dict):
                for key in ('data', 'records', 'value', 'entities'):
                    if key in parsed and isinstance(parsed[key], list):
                        return parsed[key]
                return [parsed]
            return []

        if file_format == 'text':
            return [
                {'line_number': i, 'line_content': line, 'source_file': source_key}
                for i, line in enumerate(text.splitlines(), start=1)
            ]

        if file_format == 'parquet':
            import pandas as pd
            return pd.read_parquet(io.BytesIO(body_bytes)).to_dict(orient='records')

        raise ValueError(f"Unsupported file_format: '{file_format}'.")
